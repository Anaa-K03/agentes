# Bitácora de incidentes del equipo

| Hora (Panamá) | Secuencia E1–E6 | Síntoma | Fuente y evidencia (operation_Id, log, captura) | Hipótesis | Responsable | Cambio mínimo/commit | Validación | CTFd: pregunta/respuesta revisada | Estado |
|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | |

**Checklist por incidente:** detectado / observado / analizado / hipótesis verificable / corregido / validado en salud y funcionalidad / respuesta cotejada.

**No insertar secretos ni capturas con tokens.**
