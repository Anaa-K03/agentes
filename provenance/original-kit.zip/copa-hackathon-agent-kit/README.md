# COPA Hackathon 2026 — Kit de cuatro agentes

**Propósito:** asistir a un equipo de cuatro personas en el reto Microsoft de diagnóstico y corrección de aplicaciones preexistentes. No sustituye los repositorios oficiales del evento.

## Agentes
1. `azure-sre`: aprovisionamiento existente, diagnóstico de Azure Monitor, Application Insights y Terraform.
2. `backend-dotnet`: C#/.NET, excepciones, configuración, contratos HTTP y dependencias.
3. `frontend-react`: React, variables de compilación, Network/Console, CORS y contratos API.
4. `incident-commander`: coordinación, evidencia, secuencia de seis fallos, validación y respuestas CTFd.

## Principios de competición
- **No** construir una aplicación nueva, scripts Terraform nuevos o cambiar la lógica funcional salvo autorización explícita de los retos.
- Seguir Detectar → Observar → Analizar → Hipótesis → Corregir → Validar.
- Todos pueden investigar en paralelo, pero el reto contiene problemas secuenciales; no correr correcciones incompatibles en paralelo.
- La charla indica máximo dos personas conectadas a Azure, y el uso del portal Azure en vez de CLI para el reto Microsoft: confirmar al comenzar con los organizadores.
- IA y consulta documental permitidas según la transcripción; **no** usar mensajería digital, externos ni celulares durante la prueba. Confirmar reglas oficiales definitivas en la sede.
- No automatizar ni enviar respuestas CTFd sin que un integrante las compruebe.
- No guardar credenciales, claves ni tokens en el repositorio. No copiar información confidencial del entorno de competición a un repositorio público.

## Uso
- Compartir este repositorio privado con los cuatro participantes.
- Cada persona usa ChatGPT Work/Codex con el archivo de su agente en `agents/` y el `SKILL.md` correspondiente.
- No son procesos autónomos por sí solos: son instrucciones reutilizables. Para invocación automática hay que conectarlos/configurarlos en la herramienta elegida.
- Consultar `knowledge/source-map.md` y `templates/incident-log.md`.
- Pedir a Work que cree el repositorio privado y cargue estos archivos; revisar derechos y conectores.

## Verificación pendiente
- URL concreta y materiales completos del apartado workshops (algunos contenidos pueden requerir inicio de sesión); enlaces públicos en `knowledge/source-map.md`.
- Repositorios oficiales IaC / backend / frontend, asignados el día del reto.
- Guía definitiva de reglas y rúbrica cuando la organización la entregue.
