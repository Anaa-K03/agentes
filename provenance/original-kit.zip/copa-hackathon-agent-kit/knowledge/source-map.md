# Mapa de fuentes y prioridad

## Documentos del usuario (2026-10-30)
- **Copa(1).pdf** (transcripción de preguntas y respuestas, 10 pp): aplicación entregada, no desarrollar desde cero; backend .NET/C#, frontend React; tres repos oficiales (IaC, backend, frontend); seis errores secuenciales; Azure portal; suscripción compartida con RG exclusivo; máximo dos accesos Azure por equipo; CTFd cerrado y puntos de equipo; IA y consulta documental permitidas pero no mensajería digital durante la prueba. El audio transcrito está truncado después de 30 minutos: verificar instrucciones finales con el mentor.
- **Charla 2 - Operacion Bajo Presion - Microsoft.pdf** (25 pp): 6 pasos SRE, KQL de cuatro patrones, `operation_Id`, casos 500/config/frontend URL/contrato/CORS, health vs deep health, bitácora.
- **Sesion 1 - Observabilidad Inteligente con Dynatrace.pdf** (21 pp): logs/métricas/trazas, Grail, Smartscape, PurePath, infraestructura VMs/K8s, DQL. Relevante para formación de observabilidad, no sustituye Application Insights del track Microsoft.
- **Conceptos Clave de Observabilidad en Dynatrace.pdf** (4 pp): observabilidad end-to-end, DQL, impacto empresarial, LiveDebugger, AppSec y business events.
- **Guia del Estudiante - Dynatrace.pdf** (14 pp): Playground, University y curso Essentials (9 lecciones ~4h30).

## Página oficial
- https://hackathoncopa.com/ — temas DevOps, APIs y observabilidad; workshops de preparación.
- https://hackathoncopa.com/recursos — recursos de preparación. También incluye **Cápsulas Informativas — Microsoft (17 cápsulas)** que se deben descargar/leer desde allí si no están adjuntas en la sesión actual.
- https://hackathoncopa.com/faqs — equipos de cuatro, preparativos y condiciones generales.

## Restricciones de interpretación
- No suponer que Dynatrace se usará en el reto Microsoft: los materiales del mismo señalan Azure Monitor + Application Insights.
- Los workshops son una guía de preparación, no una licencia para cambiar lógica o crear recursos fuera de la consigna.
- Antes de integrar una fuente web, registrar URL, fecha y sección, y extraer material realmente disponible; si workshop tiene video inaccesible, anotar pendiente (no inventar transcripción).
