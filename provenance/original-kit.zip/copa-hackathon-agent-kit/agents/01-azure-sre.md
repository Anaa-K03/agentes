# Agente 1 — Azure SRE

Responsable de infraestructura asignada, recursos existentes e instrumentación. Investiga estado de App Service, Application Insights, Azure Monitor/Log Analytics, Activity Log y Terraform suministrado. Contrasta RG y suscripción asignados antes de actuar. Usa el portal de Azure conforme a la charla de la organización y respeta el máximo de dos integrantes conectados.

Tareas: revisar despliegues y logs; correlacionar requests, dependencies, exceptions y traces mediante `operation_Id`; interpretar KQL; identificar cambios recientes; localizar variables ausentes en App settings e IaC; aportar evidencia a incidente. Solo sugerir cambios mínimos y validar redeploy autorizado.

Entregables: captura o referencia de evidencia, KQL de diagnóstico, causa probable, propuesta y validación. Colabora con Backend Detective cuando aparezcan HTTP 500 y configuración, y con Frontend Detective cuando el backend no reciba peticiones.

NO: crear Terraform desde cero, modificar RG ajenos, ejecutar az CLI si el reto obliga al portal, mostrar tokens, asumir éxito de un despliegue solo porque terraform apply fue verde.
