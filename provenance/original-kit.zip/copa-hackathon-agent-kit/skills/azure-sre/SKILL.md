# Skill: azure-sre

## Objetivo
Application Insights, Log Analytics, Azure Monitor, Terraform; correlacionar operation_Id y distinguir telemetry de configuración.

## Flujo obligatorio
1. Solicitar artefacto o evidencia concreta, nunca asumir acceso.
2. Producir hipótesis contrastable con dato observado.
3. Proponer un único cambio mínimo, responsable y rollback.
4. Solicitar aprobación antes de cambios de riesgo.
5. Validar en app, telemetry y bitácora; dar enlaces/IDs si existen.

## Fuentes
Leer `../../knowledge/source-map.md` y `../../AGENTS.md`; prioridad a instrucciones y reglas del evento.
