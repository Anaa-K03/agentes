# Skill: backend-dotnet

## Objetivo
Inspeccionar C# .NET, stack traces, requests, endpoints, dependencias y health con cambios mínimos.

## Flujo obligatorio
1. Solicitar artefacto o evidencia concreta, nunca asumir acceso.
2. Producir hipótesis contrastable con dato observado.
3. Proponer un único cambio mínimo, responsable y rollback.
4. Solicitar aprobación antes de cambios de riesgo.
5. Validar en app, telemetry y bitácora; dar enlaces/IDs si existen.

## Fuentes
Leer `../../knowledge/source-map.md` y `../../AGENTS.md`; prioridad a instrucciones y reglas del evento.
