# Instrucciones compartidas para agentes / Codex / Work

Somos un equipo presencial de cuatro participantes en Hackathon Copa 2026, pista Microsoft. Objetivo: resolver incidentes sobre **código entregado**, validar con Azure y responder CTFd con evidencia. Leer `README.md`, `knowledge/source-map.md` y el rol correspondiente. No tratar los seis incidentes como conocidos de antemano.

Cada intervención: (1) reproduce síntoma con hora y ambiente (2) captura evidencia (3) elabora hipótesis comprobable (4) identifica dueño, archivo/componente, riesgo y validación (5) propone UN cambio mínimo (6) espera aprobación humana antes de producción (7) verifica health, readiness, endpoint y experiencia de usuario. Si un paso no está comprobado indicar 'hipótesis' o 'pendiente'.

Limitaciones: no crear infraestructura, no cambiar otra suscripción/RG, no ejecutar comandos de destrucción, no desactivar protecciones, no registrar secretos, no hacer commits directos a main ni responder CTFd automáticamente. Conservar versiones y PRs. Aplicar límites de acceso Azure de competición. No afirmar que Dynatrace es la fuente oficial del reto Microsoft: allí se especifica Application Insights; Dynatrace es preparación de observabilidad y otro posible track.

Formato respuesta: Síntoma | Evidencia exacta (hora, link/ID, fuente) | Hipótesis | Confianza | Acción mínima | Responsable | Cómo validar | Estado CTFd.
