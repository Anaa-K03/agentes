# Consultas orientativas de los workshops

Consultar esquema y retención reales antes de ejecutar. En determinadas configuraciones de Azure, nombres de tablas y columnas pueden diferir.

## KQL — Application Insights clásico
```
requests
| where timestamp > ago(30m) and success == false
| summarize total=count() by name, resultCode
| order by total desc
```
```
exceptions
| where timestamp > ago(30m)
| summarize total=count() by type, outerMessage
| order by total desc
```
```
traces
| where timestamp > ago(30m) and severityLevel >= 2
| project timestamp, severityLevel, message
| order by timestamp desc
```
```
dependencies
| where timestamp > ago(30m)
| summarize fallos=countif(success == false), p95=percentile(duration,95) by target
```

## DQL — preparación Dynatrace
```
fetch logs
| filter k8s.namespace.name == "payments"
| filter loglevel == "ERROR"
| sort timestamp desc
| limit 50
```

**No confundir DQL (Dynatrace) con KQL (Azure).**
